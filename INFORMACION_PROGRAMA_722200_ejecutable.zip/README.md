# **sena-base-info-2021 v2.0.0**

## **Enlace GitHubPages**

[https://ecored-sena.github.io/ECORED-BASE-INFO-2021/](https://ecored-sena.github.io/ECORED-BASE-INFO-2021/)

#
